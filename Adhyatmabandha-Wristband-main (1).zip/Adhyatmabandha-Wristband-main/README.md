This repository contains the project files for the Adhyatmabandha Wristband, developed and submitted for the Aakruti International Competition organized by Dassault Systèmes, Pune.
This is smart health and safety wristband which aims to minitor the health of the individual in the crowd also generating teh prealert for an individual.
Even an common person can also afford it at an low cost of below 400 rs.
This is mainly used for the helath monitoring with the quad led along with the buzzer beep included.
